package com.example.OlimpiadasUNAM;


import com.example.OlimpiadasUNAM.Controlador.ControladorEntrenador;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class OlimpiadasUNAMApplication {

    public static void main(String[] args) {
        SpringApplication.run(OlimpiadasUNAMApplication.class, args);
    }

}
