package com.example.OlimpiadasUNAM.Servicio;
import com.example.OlimpiadasUNAM.Modelo.Entrenador;

public interface ServicioEntrenador{

Entrenador getEntrenador(Integer numcuenta);



}