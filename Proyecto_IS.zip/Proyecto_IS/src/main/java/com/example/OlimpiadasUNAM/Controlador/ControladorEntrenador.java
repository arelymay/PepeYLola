package com.example.OlimpiadasUNAM.Controlador;
import com.example.OlimpiadasUNAM.Modelo.Entrenador;
import com.example.OlimpiadasUNAM.Servicio.Impl.ServicioEntrenadorImpl;
import com.example.OlimpiadasUNAM.Servicio.ServicioEntrenador;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController

public class ControladorEntrenador {

    @Autowired
    private ServicioEntrenadorImpl servicioEntrenador;

    @RequestMapping("/consultarEntrenador")
    public String consultarEntrenador(){
        return  "ConsultarEntrenador";
    }
    @GetMapping("consultarEntrenador/{numcuenta}")
    public ResponseEntity<Entrenador>  getRegion(@PathVariable int numcuenta){
         return new ResponseEntity<>(servicioEntrenador.getEntrenador(numcuenta), HttpStatus.OK);
    }


}