package com.example.OlimpiadasUNAM.Servicio.Impl;

import com.example.OlimpiadasUNAM.Modelo.Entrenador;
import com.example.OlimpiadasUNAM.Repositorio.RepositorioEntrenador;
import com.example.OlimpiadasUNAM.Servicio.ServicioEntrenador;
import com.example.OlimpiadasUNAM.exception.ApiException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class ServicioEntrenadorImpl implements ServicioEntrenador {

    @Autowired
    RepositorioEntrenador repo;
    @Override
    public Entrenador getEntrenador(Integer numcuenta) {
        Entrenador entrenador = repo.findByNumCuenta(numcuenta);
        if(entrenador == null)
            throw new ApiException(HttpStatus.NOT_FOUND, "entrenador no existe");
        else
            return entrenador;

    }
}
