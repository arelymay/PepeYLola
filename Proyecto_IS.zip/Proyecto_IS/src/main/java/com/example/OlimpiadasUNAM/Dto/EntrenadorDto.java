package com.example.OlimpiadasUNAM.Dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor

public class EntrenadorDto {
    private int numcuenta;
    private String nombre;
    private String apellidopaterno;
    private String apellidomaterno;
    private String institucion;
    private String correo;
    private String contrasena;
    private String disciplina;

}
